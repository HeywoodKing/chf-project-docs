A Pen created at CodePen.io. You can find this one at http://codepen.io/Vince_Brown/pen/BNazqL.

 Work in progress. Going to be an animated svg travel timeline
Inspired by <a href="https://dribbble.com/shots/2029010-Travel-Summary?list=searches&tag=travel&offset=12"> this dribble shot</a>